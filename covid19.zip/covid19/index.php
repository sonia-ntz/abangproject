<?php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.kawalcorona.com/indonesia/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$content = curl_exec($ch);
curl_close($ch);
$result=json_decode($content,true);
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pantau Covid-19</title>

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  </head>

  <body>
    <div class="jumbotron">
      <div class="container">
        <h1 class="display-3">Pantau COVID19 !</h1>
        <p>Belajar membuat halaman web yang menampilkan jumlah kasus covid19 di Indonesia</p>
      </div>
    </div>
    <?php
    foreach ($result as $value) {
      // code...
    echo '
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <h2>'.$value['positif'].'</h2>
          <p>Konfirmasi Positif</p>
        </div>
        <div class="col-md-3">
          <h2>'.$value['sembuh'].'</h2>
          <p>Sembuh</p>
        </div>
        <div class="col-md-3">
          <h2>'.$value['dirawat'].'</h2>
          <p>Dirawat</p>
        </div>
        <div class="col-md-3">
          <h2>'.$value['meninggal'].'</h2>
          <p>Meninggal</p>
        </div>
      </div>
    </div>';
    }
     ?>
    <nav class="navbar fixed-bottom navbar-expand-sm navbar-dark bg-dark">
      <a class="navbar-brand" href="#">Pantau Covid19 - Sonia</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="assets/js/jquery-slim.min.js"><\/script>')</script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>
